"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { uploadFile, downloadFile } from "./actions"

export default function Home() {
  const [file, setFile] = useState<File | null>(null)
  const [uploadedCode, setUploadedCode] = useState<string | null>(null)
  const [downloadCode, setDownloadCode] = useState("")
  const [downloadLink, setDownloadLink] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFile(e.target.files[0])
    }
  }

  const handleUpload = async () => {
    if (!file) return
    try {
      const code = await uploadFile(file)
      setUploadedCode(code)
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to upload file. Please try again.")
    }
  }

  const handleDownload = async () => {
    try {
      const link = await downloadFile(downloadCode)
      setDownloadLink(link)
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to retrieve file. Please check your code and try again.")
    }
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <Card className="w-[350px]">
        <CardHeader>
          <CardTitle>Secret File Share</CardTitle>
          <CardDescription>Upload or download files securely</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Input type="file" onChange={handleFileChange} />
              <Button onClick={handleUpload} className="mt-2" disabled={!file}>
                Upload
              </Button>
            </div>
            {uploadedCode && (
              <div>
                <p>Your secret code:</p>
                <code className="bg-gray-100 p-2 rounded">{uploadedCode}</code>
              </div>
            )}
            <div>
              <Input
                type="text"
                placeholder="Enter secret code"
                value={downloadCode}
                onChange={(e) => setDownloadCode(e.target.value)}
              />
              <Button onClick={handleDownload} className="mt-2">
                Download
              </Button>
            </div>
            {downloadLink && (
              <div>
                <p>Your download link:</p>
                <a href={downloadLink} className="text-blue-500 underline" target="_blank" rel="noopener noreferrer">
                  Download File
                </a>
              </div>
            )}
            {error && <p className="text-red-500">{error}</p>}
          </div>
        </CardContent>
      </Card>
    </main>
  )
}

