"use server"

import { revalidatePath } from "next/cache"

// First, we need to get the best server to use
async function getBestServer() {
  const response = await fetch("https://api.gofile.io/Servers")
  if (!response.ok) {
    throw new Error("Failed to get server")
  }
  const data = await response.json()
  if (data.status !== "ok") {
    throw new Error(data.status)
  }
  return data.data.server
}

export async function uploadFile(file: File): Promise<string> {
  try {
    const server = await getBestServer()
    const API_URL = `https://api.gofile.io/Servers`

    const formData = new FormData()
    formData.append("file", file)

    const response = await fetch(`https://{server}.gofile.io/contents/uploadfile`, {
      method: "POST",
      body: formData,
    })

    if (!response.ok) {
      throw new Error("Failed to upload file")
    }

    const data = await response.json()

    if (data.status !== "ok") {
      throw new Error(data.status)
    }

    revalidatePath("/")
    return data.data.code
  } catch (error) {
    console.error("Upload error:", error)
    throw new Error("Failed to upload file. Please try again.")
  }
}

export async function downloadFile(code: string): Promise<string> {
  try {
    const response = await fetch(`https://api.gofile.io/contents/{contentId}/directlinks?contentId=${code}`, {
      method: "POST",
    })

    if (!response.ok) {
      throw new Error("Failed to retrieve file")
    }

    const data = await response.json()

    if (data.status !== "ok") {
      throw new Error(data.status)
    }

    revalidatePath("/")
    return data.data.contents[Object.keys(data.data.contents)[0]].link
  } catch (error) {
    console.error("Download error:", error)
    throw new Error("Failed to retrieve file. Please check your code and try again.")
  }
}

